# Mayaajaal Android starter project

**App name:** Mayaajaal  
**Tagline:** Smart Indian Market Intelligence  
**Package ID:** `com.mayaajaal.app`

## What is included
- Android Studio project using a native Android WebView shell.
- Rebranded version of the supplied Mayaansh Market Desk HTML prototype.
- Navy-and-gold launcher icon vector.
- Local HTML/CSS/JavaScript assets bundled inside the app.
- Local browser storage for the prototype's watchlist, activity log, and preferences.

## Important current limitations
This is a **starter project**, not a finished production trading or market-data app.
- The supplied prototype explicitly labels watchlist prices as illustrative/sample values.
- No live NSE/BSE feed is connected.
- No broker connection or trade execution exists.
- The original HTML's scheduled prompts work only while the app page is active. Android background notifications have not been implemented.
- Portfolio tracking, real-time alerts, and market analysis listed in the roadmap are not yet implemented.
- The app must not imply that sample values are live prices or investment recommendations.

## Build an Android App Bundle (AAB)
1. Install the latest stable Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete.
4. Select **Build > Generate Signed Bundle / APK**.
5. Choose **Android App Bundle**.
6. Create and securely back up your upload keystore. Never share the keystore or passwords.
7. Build the release bundle. Android Studio will produce an `.aab` file.

The project uses Android Gradle Plugin 8.7.3 and compile/target SDK 35. If Android Studio recommends a compatible Gradle/JDK update, apply its supported migration.

## Before Google Play submission
- Replace sample/demo values with a properly licensed data source, or keep the app clearly in demo mode.
- Implement and test Android notification behavior if scheduled alerts are advertised.
- Add a public privacy policy URL and complete Play Console Data safety disclosures accurately.
- Prepare actual screenshots from the final working app. Do not use mockup screens or invented quotes as evidence of implemented functionality.
- Complete Google Play's app content, financial features, target audience, and testing declarations.
- Use the developer account owner's real legal identity and contact details.

## Privacy notes for this prototype
The current HTML stores watchlist, prompt log, and preferences in local WebView storage on the device. This starter project does not add analytics, advertising SDKs, account login, or a remote backend. Reassess the privacy policy and Data safety form if you add any SDK, backend, account, analytics, or data provider.

## Suggested next development milestones
1. Native Android notifications and reliable scheduling.
2. Licensed market-data provider integration (free/delayed tier first, paid real-time tier later).
3. Portfolio tracker with clear manual-entry and data-source labels.
4. Market dashboard and insight modules backed by verifiable sources.
5. Accessibility, security, offline behavior, device testing, and Play policy review.


## Phone-only cloud build (GitHub Actions)
This project includes `.github/workflows/android-build.yml`.
1. On your Android phone, sign in to GitHub in Chrome and create a **private** repository.
2. Upload the contents of this project ZIP to the repository (extract the ZIP first with your file manager).
3. Open the repository's **Actions** tab and allow workflows if GitHub asks.
4. Run **Build Mayaajaal Android app** (or push to `main` to trigger it).
5. Open the completed workflow run and download the `mayaajaal-android-build` artifact.
6. The artifact contains a debug APK for device testing and an **unsigned** release AAB.

The AAB produced by this starter workflow is unsigned and is **not ready for Play Console upload**. A secure upload keystore and signing step must be configured before release. Never put keystore files or passwords in the repository. Android's official instructions explain app-bundle signing and Play App Signing.

# Mayaajaal – Privacy Policy (Draft)

**Effective date:** [Insert date]  
**Developer:** [Insert legal developer name and contact email]

Mayaajaal is currently a prototype market-monitoring application.

## Information stored
The current prototype stores the watchlist, activity log, and user preferences locally in the app's WebView storage on the device. The prototype does not include account registration, advertising, analytics, or a remote server.

## Market information
The current watchlist contains illustrative sample values and is not connected to a live NSE/BSE feed. Do not treat sample values or generated prompts as investment advice.

## Sharing
The current prototype does not transmit the locally stored watchlist, activity log, or preferences to the developer. This statement must be reviewed if remote services, analytics, crash reporting, notifications, or market-data providers are added.

## Children's privacy
The app is not designed for children.

## Security and retention
Locally stored data remains on the device until app data is cleared or the app is uninstalled. Device-level security settings may affect protection.

## Changes and contact
This draft must be completed with the developer's legal identity, contact details, and final data practices before publication.  
Contact: [Insert support email]

**Important:** This is a draft, not legal advice. Update it to match the final app and every SDK or third-party service used.

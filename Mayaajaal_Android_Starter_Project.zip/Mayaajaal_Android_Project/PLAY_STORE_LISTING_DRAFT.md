# Google Play listing draft

**App name:** Mayaajaal  
**Short description:** A calm, rules-based workspace for tracking Indian equities and reviewing market risks.

**Full description:**
Mayaajaal is a personal market-monitoring workspace designed to help users organise an Indian-equity watchlist and build a disciplined review routine.

Current prototype features:
- Custom NSE watchlist.
- Morning review prompts and repeatable market checklist.
- Risk-posture and investing-focus preferences.
- Local activity log and JSON export.
- Clear reminders to verify prices, filings, liquidity, and downside risk.

Important: This prototype does not provide live market quotes, execute trades, connect to a broker, or guarantee predictions. Any sample values are illustrative only. Prompts are educational workflow aids, not personalised investment advice.

**Category suggestion:** Finance (confirm eligibility and Play Console requirements before submission).

**Store asset note:** Create final screenshots from the actual tested app. Do not use concept mockups containing fabricated market prices as screenshots.
